package pkg_locators;
import org.openqa.selenium.By;
import pkg_global.GlobalObjects;

public class Locator_VarietyOther extends GlobalObjects {

    public static By Btn_AlertBox        = By.id("promptBox");
    public static By Lnk_PokOnGithub     = By.cssSelector("img[alt='Fork me on GitHub']");

}
