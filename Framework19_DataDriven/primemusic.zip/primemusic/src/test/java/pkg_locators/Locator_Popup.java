package pkg_locators;
import org.openqa.selenium.By;
import pkg_global.GlobalObjects;

public class Locator_Popup extends GlobalObjects {
    public static By Lnk_Popup              = By.id("restart-ad");
    public static By Btn_Popupclose         = By.xpath("//p[text()='Close']");
}
