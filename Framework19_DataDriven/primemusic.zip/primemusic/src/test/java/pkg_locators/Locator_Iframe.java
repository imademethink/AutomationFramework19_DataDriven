package pkg_locators;

import org.openqa.selenium.By;
import pkg_global.GlobalObjects;

public class Locator_Iframe extends GlobalObjects {

    public static By Txtbx_Iframe           = By.id("tinymce");


}
