package pkg_locators;

import org.openqa.selenium.By;
import pkg_global.GlobalObjects;

public class Locator_Multiwindow extends GlobalObjects {

    public static By Lnk_Multiwindow        = By.xpath("//a[text()='Click Here']");


}
